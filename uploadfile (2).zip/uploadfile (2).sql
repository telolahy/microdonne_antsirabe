-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : ven. 11 avr. 2025 à 08:18
-- Version du serveur : 8.2.0
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `uploadfile`
--

-- --------------------------------------------------------

--
-- Structure de la table `badge_views`
--

DROP TABLE IF EXISTS `badge_views`;
CREATE TABLE IF NOT EXISTS `badge_views` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `enquete_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `badge_views_user_id_foreign` (`user_id`),
  KEY `badge_views_enquete_id_foreign` (`enquete_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `badge_views`
--

INSERT INTO `badge_views` (`id`, `user_id`, `enquete_id`, `created_at`, `updated_at`) VALUES
(1, 22, 2, '2025-04-02 07:12:20', '2025-04-02 07:12:20');

-- --------------------------------------------------------

--
-- Structure de la table `directions`
--

DROP TABLE IF EXISTS `directions`;
CREATE TABLE IF NOT EXISTS `directions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `directions`
--

INSERT INTO `directions` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'DSIC', NULL, NULL, NULL),
(2, 'DDSS', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `downloads`
--

DROP TABLE IF EXISTS `downloads`;
CREATE TABLE IF NOT EXISTS `downloads` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `file_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `validated_by` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` enum('en_attente','valide','rejete') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en_attente',
  `checked` tinyint(1) NOT NULL DEFAULT '1',
  `motif` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `downloads_file_id_foreign` (`file_id`),
  KEY `downloads_user_id_foreign` (`user_id`),
  KEY `downloads_validated_by_foreign` (`validated_by`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `download_tokens`
--

DROP TABLE IF EXISTS `download_tokens`;
CREATE TABLE IF NOT EXISTS `download_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `file_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `download_tokens_token_unique` (`token`),
  KEY `download_tokens_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `download_tokens`
--

INSERT INTO `download_tokens` (`id`, `email`, `user_id`, `token`, `expires_at`, `file_id`) VALUES
(1, 'magdella_emile@yahoo.com', 7, 'Cz4ScQaU1OQJsV5j4fSWE9tqgySTfxrX90GwtJCF', '2025-03-03 17:27:43', 2),
(2, 'magdella_emile@yahoo.com', 7, 'IRpfQZWy4TfEcoIu08D4GSa3fOjlbk98dGpSaAU9', '2025-03-03 17:28:30', 2),
(7, 'magdella_emile@yahoo.com', 7, 'RVuN7mI2VKfQewk8PllTmoOrfwX1asG5Fujj5YG8', '2025-03-03 18:09:05', 18),
(9, 'magdella_emile@yahoo.com', 7, 'PkbMeNGzDq2YFOQZfHsyAnjjXBIBS3YEgtGKIgd4', '2025-03-03 18:11:27', 18),
(11, 'magdella_emile@yahoo.com', 7, '0YSaTfU7gr9zaET36hMwAgLaDDYXtXk0Rcv8uGGW', '2025-03-03 18:21:50', 18),
(12, 'magdella_emile@yahoo.com', 7, 'sF5lupnidkXxbaG9spuhE8YcWb7vjzg4uZTP5e4s', '2025-03-03 18:22:15', 18),
(13, 'magdella_emile@yahoo.com', 7, 'Y2LKGDeGR3jT70e8BrCBaejYBTt2MRPvKv5SpxAI', '2025-03-04 03:38:02', 18),
(14, 'magdella_emile@yahoo.com', 7, 'oZW99gMVB21SO4N1Yu4qKYmi99He1lenO7Axys84', '2025-03-04 03:46:37', 18),
(15, 'magdella_emile@yahoo.com', 7, 'uoXI4i3VcQDnnr0wmAYmM9IgMvNf9SQtdPAeZcTG', '2025-03-04 03:48:17', 18),
(16, 'magdella_emile@yahoo.com', 7, 'cDkkveGPe05AmzNhcrLSQn6fSqAUjRUCh86wCm6A', '2025-03-04 06:14:02', 18),
(17, 'magdella_emile@yahoo.com', 7, 'hl6Kec9DfnRXTPSUJiNQGIe8BJdr4eTViAYTgaeC', '2025-03-04 06:14:18', 18),
(18, 'magdella_emile@yahoo.com', 7, '2dydeYW4hiiV5TDTUcUuM4jaAhulcNDn3ONk8EAU', '2025-03-04 08:54:34', 18),
(19, 'magdella_emile@yahoo.com', 7, 'U97CaWPRnwXUfGjGf8rsY7Xiq13LeXsc63qbd4Ez', '2025-03-04 08:55:23', 18),
(20, 'magdella_emile@yahoo.com', 7, 'RjkuvaVdhNOxOUMfkCzOwpjQxFHxvOrznuqkHwi0', '2025-03-04 08:55:38', 18),
(21, 'magdella_emile@yahoo.com', 7, '8HN3E4K7vq4chpKM1BB96rftTnOXbIkbxiQInNrc', '2025-03-04 09:01:01', 18),
(22, 'magdella_emile@yahoo.com', 7, 'UH2SA1t1Msm4bkcWDbGSWsM3ZYF3k0VPN5w2je7C', '2025-03-07 13:56:22', 18),
(23, 'magdella_emile@yahoo.com', 7, 'ln4eRY4iJIx2guA5lFhSG2JPIUF7azZeN4f71p3F', '2025-03-12 03:53:17', 18),
(24, 'magdella_emile@yahoo.com', 7, 'f6jfTNcmRVe30f3iN2FKHdEWQWcpswkN1aIhJSOA', '2025-03-12 04:04:49', 18),
(25, 'magdella_emile@yahoo.com', 7, 'XuYY8wfNjkf6zmbyJ0JF6SNo3DEe18rhtN8JFomG', '2025-03-12 04:11:55', 18),
(26, 'rabe@gmail.com', 3, 'GvTfUN8DyWS31XMbB8wiVZlD2hfO4IcjAVGU29gv', '2025-03-12 04:47:46', 18),
(27, 'magdella_emile@yahoo.com', 7, '4jMn5t2l4RVLLf5GrMVdn2Br1y9FPHNfNdMQZpPd', '2025-03-12 04:53:49', 18),
(28, 'magdella_emile@yahoo.com', 7, 'srOVbg1ENM2UpZ1JVxslBzum0ox9GSCH9MH6klms', '2025-03-12 04:58:12', 18),
(29, 'antonellanirina19@gmail.com', 21, 'TOMSRvGxoSl3ZennJQAu5xHRlju3LR3o8golMMuR', '2025-03-27 05:00:50', 27),
(30, 'antonellanirina19@gmail.com', 21, 'o0xxuHrNVe8IFyrLB91QZVsFyZJLJPZZCyXmXkn5', '2025-03-27 07:47:31', 27),
(31, 'antonellanirina19@gmail.com', 22, 'gOhe5ULElJ2lzX6kw5qOi5YuOD2ex1WT53ARsWxO', '2025-03-27 08:32:31', 28),
(32, 'antonellanirina19@gmail.com', 22, 'c2CxOT9RzWU27Qujyprc860fsmGwSQT8WSCwARZS', '2025-04-01 09:25:55', 28),
(33, 'antonellanirina19@gmail.com', 22, 'AMqaRDefFakFb93hm5YsWypuLXP3H1FaIrQ10Nde', '2025-04-03 08:58:49', 25),
(34, 'antonellanirina19@gmail.com', 22, 'lcrPgFXTkQ7JmNceSukGcnR0DNqhV2TyurdxkheK', '2025-04-04 03:28:50', 28),
(35, 'antonellanirina19@gmail.com', 22, 'nbM4MlPzRtkWHMpUZfsCfHM2oieAVqIGqsRegLF6', '2025-04-07 08:41:08', 30),
(36, 'antonellanirina19@gmail.com', 22, 'ppe7raaNrgwYHCL8Xwpp6abR1nmt7wLWGdWuIoHw', '2025-04-07 08:46:52', 34),
(37, 'antonellanirina19@gmail.com', 22, 'R3Kue0KIwWCma0TazjpxosqIXxpjJGw6LEfZl6x9', '2025-04-07 08:48:37', 29),
(38, 'antonellanirina19@gmail.com', 22, 'L5GttzYVU4VVxnjHrcONXdi0nvGtEoDkDDZWAgHe', '2025-04-08 14:48:31', 36),
(39, 'antonellanirina19@gmail.com', 22, 'ISwgEewZVTrhwlIWUUiMabJdQ0iHyHDkIdYct9hW', '2025-04-09 03:58:34', 25),
(40, 'antonellanirina19@gmail.com', 22, 'H0ZqrYOaZnWx3LMFtupsMQWB8xod0WCcIrFBlp6o', '2025-04-10 03:59:06', 40),
(41, 'antonellanirina19@gmail.com', 22, '4XuD9lvXKdjDD2prKjMydwWhLJm4zr8MXDb4KyAL', '2025-04-10 04:07:23', 27),
(42, 'antonellanirina19@gmail.com', 22, 'wwFbjsCEg9d7h68NNeCaLizP29zcGcroSZoogxeR', '2025-04-10 04:52:57', 43);

-- --------------------------------------------------------

--
-- Structure de la table `enquetes`
--

DROP TABLE IF EXISTS `enquetes`;
CREATE TABLE IF NOT EXISTS `enquetes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `direction_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `has_new_data` tinyint(1) NOT NULL DEFAULT '0',
  `images` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enquetes_direction_id_foreign` (`direction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `enquetes`
--

INSERT INTO `enquetes` (`id`, `nom`, `description`, `direction_id`, `created_at`, `updated_at`, `has_new_data`, `images`) VALUES
(1, 'Population', 'La population d\'un territoire représente l\'ensemble des individus qui y vivent à un moment donné. Elle peut être décrite selon plusieurs critères tels que l\'âge, le sexe, la situation géographique, les niveaux d\'éducation, et les activités économiques. L\'analyse de la population est cruciale pour comprendre les dynamiques sociales, économiques et environnementales d\'une région. En effet, les données démographiques aident les gouvernements et les organisations à planifier des politiques publiques adaptées aux besoins des citoyens, comme la santé, l\'éducation, ou encore le logement. L\'évolution de la population, qu\'elle soit due à la natalité, la mortalité, ou les migrations, impacte directement les sociétés et leur développement', 1, '2025-03-24 12:19:52', '2025-04-04 04:22:17', 0, 'jdxVWWs7lF1t85OjYz45HH0yAXjdC5A8aDX96EI3.png'),
(2, 'Test', 'Épreuve qui permet de déceler les aptitudes d\'une personne et fournit des renseignements sur ses connaissances, son caractère, etc.', 1, '2025-03-25 02:08:16', '2025-04-09 04:03:18', 1, 'jmQpSwueFyqtl2quuLPc2pKb05JYY1AQZj8Htziy.png'),
(20, 'Covid-19', 'Taux de mortalité', 1, '2025-04-09 08:37:43', '2025-04-09 08:37:43', 0, '1744198663.png'),
(21, 'qwert', 'wertyh', 1, '2025-04-09 08:54:14', '2025-04-09 08:54:14', 0, '1744199654.png'),
(10, 'qawertyu', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, erat ut facilisis scelerisque, nulla dui efficitur enim, eu blandit nunc nisi vel sapien. Fusce iaculis, nisl sit amet pretium malesuada, lectus elit dapibus orci, vel tincidunt tortor dui et sapien. Aliquam erat volutpat. Proin tempor leo ut sapien gravida, sed volutpat est convallis. Curabitur malesuada lorem eu sapien sodales scelerisque. Sed aliquam ligula a augue tincidunt, a fermentum felis dapibus. Aenean maximus ac purus nec dapibus.\r\n\r\nMauris sollicitudin, libero et elementum placerat, sapien lectus iaculis odio, non cursus nunc sapien sed arcu. In vehicula felis eu neque mollis, ut dictum sapien interdum. Cras eget orci sit amet ipsum auctor rhoncus. Morbi ut ipsum sed erat maximus aliquet. Vivamus viverra mauris at lacus aliquam, id condimentum erat elementum. Quisque ac orci et nunc tincidunt varius non id ligula. Integer maximus ut nunc vel placerat.\r\n\r\nNullam dapibus feugiat nisl, ac tincidunt orci aliquam a. Curabitur at dui et lacus volutpat cursus. Nam ut risus nec nisl tempor cursus. Sed eget dolor magna. Nam at lacus nec orci finibus tincidunt at id mauris. Integer ac venenatis odio. Ut sit amet purus id lectus fermentum ultricies. Nulla facilisi. Aenean tempor gravida efficitur. Ut tristique dui nec ligula vestibulum varius. Nunc malesuada, ligula ac gravida tempus,', 1, '2025-03-28 06:23:23', '2025-04-10 06:51:08', 1, '1OY5EFpHwxhaKpwzIaNnDPnupdFjmQ7b3GWA5imx.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `files`
--

DROP TABLE IF EXISTS `files`;
CREATE TABLE IF NOT EXISTS `files` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('en_attente','validé','rejeté') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en_attente',
  `direction_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `enquete_id` bigint UNSIGNED DEFAULT NULL,
  `type` enum('avec_validation','sans_validation') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'avec_validation',
  `nombre` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `files_direction_id_foreign` (`direction_id`),
  KEY `files_user_id_foreign` (`user_id`),
  KEY `files_enquete_id_foreign` (`enquete_id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `files`
--

INSERT INTO `files` (`id`, `published`, `file_name`, `file_path`, `description`, `status`, `direction_id`, `user_id`, `created_at`, `updated_at`, `enquete_id`, `type`, `nombre`) VALUES
(36, 1, 'mama.docx', 'uploads/nbGo8YkwdApVFxhY0zTwScMpi2gs44ywxFV17XOY.docx', 'test badge', 'en_attente', 1, 22, '2025-04-08 13:35:25', '2025-04-08 14:09:48', 17, 'avec_validation', 0),
(27, 1, 'mama.docx', 'uploads/mama.docx', 'test be farany', 'en_attente', 1, 1, '2025-03-26 09:20:53', '2025-04-10 03:37:38', 1, 'avec_validation', 1),
(28, 1, 'SE20220229.docx', 'uploads/SE20220229.docx', 'test modif', 'en_attente', 1, 1, '2025-03-27 02:36:52', '2025-04-09 12:00:15', 1, 'sans_validation', 0),
(29, 1, 'CAHIER-DES-CHARGES-ESMIA.docx', 'uploads/hBO62CPXHDd3X1ZEu4pkft7HVcA38PQ0ndYmF9oD.docx', 'test', 'en_attente', 1, 22, '2025-04-01 03:01:40', '2025-04-07 08:18:51', 2, 'sans_validation', 2),
(42, 0, 'SE20220229.docx', 'uploads/suOMT7Gt6EemGFB2kBgTClpbTQSKreFkEMErmBbe.docx', 'qwerty', 'en_attente', 1, 22, '2025-04-09 04:22:45', '2025-04-09 04:22:45', 10, 'avec_validation', 0),
(32, 1, 'Capture d\'écran 2025-03-05 110646.png', 'uploads/liZ4KDZWXanLhBqTO9P5H4INMr7hOZjVCLktBuix.png', 'test badge', 'en_attente', 1, 22, '2025-04-01 08:40:22', '2025-04-07 09:20:22', 17, 'sans_validation', 0),
(34, 1, 'sup.txt', 'uploads/2d7PBoSrfZYSdK1phDjiFU526oO2t49KlKMVdnQ1.html', 'lllll', 'en_attente', 1, 22, '2025-04-04 04:22:17', '2025-04-07 08:17:10', 1, 'sans_validation', 1),
(35, 1, 'uml.docx', 'uploads/j5hUxu4WpgnHdaOrgFwz8Q87gFzrpmEzql4Vx24F.docx', 'test loremmm', 'en_attente', 1, 22, '2025-04-07 09:16:57', '2025-04-07 09:17:20', 10, 'avec_validation', 0),
(40, 1, 'SE20220229.docx', 'uploads/timmgVptcdj1VmHaMKaWRkG5AVyMR0htPhKifv7E.docx', 'qwertyuisxdcvbn', 'en_attente', 1, 22, '2025-04-09 04:03:18', '2025-04-10 03:29:32', 2, 'sans_validation', 1),
(41, 1, 'SE20220229.docx', 'uploads/rvK1DmcbMmNbWZOZ2KOFQ3frEwi8oLFp4eI56k4S.docx', 'qwerty', 'en_attente', 1, 22, '2025-04-09 04:20:15', '2025-04-09 04:23:03', 10, 'avec_validation', 0),
(43, 0, 'mama.docx', 'uploads/mama.docx', 'test nom fichier', 'en_attente', 1, 22, '2025-04-10 04:22:37', '2025-04-10 04:23:19', 10, 'sans_validation', 1);

-- --------------------------------------------------------

--
-- Structure de la table `file_theme`
--

DROP TABLE IF EXISTS `file_theme`;
CREATE TABLE IF NOT EXISTS `file_theme` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `theme_id` bigint UNSIGNED NOT NULL,
  `file_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_theme_theme_id_foreign` (`theme_id`),
  KEY `file_theme_file_id_foreign` (`file_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `file_theme`
--

INSERT INTO `file_theme` (`id`, `created_at`, `updated_at`, `theme_id`, `file_id`) VALUES
(1, NULL, NULL, 2, 23),
(2, NULL, NULL, 3, 23),
(3, NULL, NULL, 3, 24),
(4, NULL, NULL, 4, 24),
(5, NULL, NULL, 3, 25),
(6, NULL, NULL, 3, 26),
(7, NULL, NULL, 3, 27),
(8, NULL, NULL, 3, 28),
(9, NULL, NULL, 3, 29),
(10, NULL, NULL, 4, 29),
(11, NULL, NULL, 5, 29),
(12, NULL, NULL, 3, 30),
(13, NULL, NULL, 3, 31),
(14, NULL, NULL, 3, 32),
(15, NULL, NULL, 3, 34),
(16, NULL, NULL, 3, 35),
(17, NULL, NULL, 4, 35),
(18, NULL, NULL, 4, 36),
(19, NULL, NULL, 7, 37),
(20, NULL, NULL, 7, 38),
(21, NULL, NULL, 13, 39),
(22, NULL, NULL, 2, 40),
(23, NULL, NULL, 2, 41),
(24, NULL, NULL, 5, 41),
(25, NULL, NULL, 2, 42),
(26, NULL, NULL, 5, 42),
(27, NULL, NULL, 2, 43),
(28, NULL, NULL, 5, 43);

-- --------------------------------------------------------

--
-- Structure de la table `historiques`
--

DROP TABLE IF EXISTS `historiques`;
CREATE TABLE IF NOT EXISTS `historiques` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `file_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `historiques_file_id_foreign` (`file_id`),
  KEY `historiques_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `historiques`
--

INSERT INTO `historiques` (`id`, `file_id`, `user_id`, `created_at`, `updated_at`) VALUES
(5, 25, 1, '2025-04-08 15:00:54', NULL),
(7, 34, 1, '2025-04-09 15:12:20', NULL),
(6, 28, 22, '2025-04-04 02:59:05', '2025-04-04 02:59:05'),
(4, 28, 22, '2025-03-27 08:02:47', '2025-03-27 08:02:47'),
(16, 27, 22, '2025-04-10 03:37:38', '2025-04-10 03:37:38'),
(17, 43, 22, '2025-04-10 04:23:19', '2025-04-10 04:23:19'),
(12, 34, 22, '2025-04-07 08:17:10', '2025-04-07 08:17:10'),
(15, 40, 22, '2025-04-10 03:29:32', '2025-04-10 03:29:32');

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2025_02_19_140148_add_role_to_users_table', 1),
(5, '2025_02_19_161507_create_roles_table', 1),
(6, '2025_02_19_194933_create_directions_table', 1),
(7, '2025_02_21_113829_create_files_table', 1),
(8, '2025_02_22_142016_create_downloads_table', 2),
(9, '2025_02_24_062404_add_status_to_downloads', 3),
(10, '2025_02_24_070656_add_checked_to_downloads', 4),
(11, '2025_02_24_082540_create_rapport_table', 5),
(12, '2025_02_24_110349_add_column_to_users', 6),
(13, '2025_02_24_112347_add_rules_to_users', 7),
(18, '2025_02_25_132632_add_motif_to_downloads_table', 8),
(19, '2025_03_03_183627_create_download_tokens_table', 8),
(20, '2025_03_03_191725_add_file_id_to_download_tokens_table', 9),
(21, '2025_03_24_110928_create-table-enquetes', 10),
(22, '2025_03_24_151443_add_enquete_id_to_files', 10),
(23, '2025_03_25_115916_create_table_themes', 11),
(24, '2025_03_25_120318_add_id_direction_to_theme', 12),
(25, '2025_03_25_121300_create_file_theme_table', 13),
(26, '2025_03_25_121401_add_theme_id_to_file_theme_table', 14),
(27, '2025_03_26_105659_add_type_to_files_table', 15),
(28, '2025_03_26_125713_add_profile_to_users_table', 16),
(29, '2025_03_27_074631_create_table_historiques', 17),
(30, '2025_03_28_090446_add_images_to_enquetes_tables', 18),
(31, '2025_03_28_104934_add_image_to_themes_tables', 19),
(32, '2025_04_01_094602_add_published_to_files_table', 20),
(33, '2025_04_01_111331_add_has_new_data_to_enquetes_table', 21),
(34, '2025_04_02_100256_create_badge_views_table', 22),
(35, '2025_04_07_110124_add_nombre_to_files', 23),
(36, '2025_04_08_115551_add_validated_by_to_downloads', 24),
(37, '2025_04_09_072135_add_nouvelle_donnee_to_themes', 25);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('keke@gmail.com', '$2y$10$uOYT.sFPiX7alH7.F2ydiepHiixOp4jMlzOyLJkObcoCm8fs3oUn.', '2025-02-27 13:15:04'),
('magdella_emile@yahoo.com', '$2y$10$ODuErnFrW76O1sAj.a0ZBeqlGVH381mn3/P.ZckKBqK83eBhuEBj6', '2025-03-12 07:25:54');

-- --------------------------------------------------------

--
-- Structure de la table `rapports`
--

DROP TABLE IF EXISTS `rapports`;
CREATE TABLE IF NOT EXISTS `rapports` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `download_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rapports_download_id_foreign` (`download_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `rapports`
--

INSERT INTO `rapports` (`id`, `path`, `download_id`, `created_at`, `updated_at`) VALUES
(9, 'rapports/mama.docx', 50, '2025-04-04 05:16:06', '2025-04-04 05:16:06'),
(24, 'rapports/mama.docx', 45, '2025-04-08 06:52:49', '2025-04-08 06:52:49');

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'utilisateur', '2025-02-22 06:01:38', '2025-02-22 06:01:38');

-- --------------------------------------------------------

--
-- Structure de la table `themes`
--

DROP TABLE IF EXISTS `themes`;
CREATE TABLE IF NOT EXISTS `themes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nbreDonnee` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `nouvelle_donnee` tinyint(1) NOT NULL DEFAULT '0',
  `direction_id` bigint UNSIGNED NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `themes_direction_id_foreign` (`direction_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `themes`
--

INSERT INTO `themes` (`id`, `nom`, `nbreDonnee`, `description`, `created_at`, `updated_at`, `nouvelle_donnee`, `direction_id`, `image`) VALUES
(2, 'Test', NULL, 'test lty e', '2025-03-25 12:25:13', '2025-04-10 04:22:37', 1, 1, '016LW91CA4sPT5gMtfdbix4Mu1yOLqb5OZ18wKaG.png'),
(3, 'Agriculture', NULL, 'Biologie', '2025-03-25 12:25:37', '2025-03-28 08:16:33', 0, 1, 'eknH17VPM6VoYDhkhhbsvH8bs9eObqcw3O0RP5VM.png'),
(4, 'Education', NULL, 'Bien lty ee', '2025-03-25 12:29:21', '2025-03-28 08:18:11', 0, 1, 'OsVUiN1Z9BXVvm6HB9fTDJl68wTSRwpRkUUymNgK.png'),
(5, 'Santé', NULL, 'Santé publique', '2025-03-26 03:34:52', '2025-04-10 04:22:37', 1, 1, 'BY87eXWFTMQ9h3ePb96gC44VTGE5DOqa0kYY1cvQ.png'),
(11, 'pagination', NULL, 'testpage', '2025-04-01 03:42:09', '2025-04-01 03:42:27', 0, 1, 'YPDrLL0ctXuxuWkU6D5DfwRx7GA1LHkR0WDpuyEl.png');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `direction_id` int DEFAULT NULL,
  `prenom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `telephone` int NOT NULL,
  `profession` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `entite` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`, `direction_id`, `prenom`, `adresse`, `telephone`, `profession`, `entite`, `profile`) VALUES
(1, 'Keke', 'keke@gmail.com', '2025-03-12 10:17:23', '$2y$10$Mdi4nk6c4wlpa1aZGOGofO7jmjybxVuUC0XqVwBpZOlF7n4MOL7xC', NULL, '2025-02-22 06:02:12', '2025-03-27 01:59:18', 'user', 1, 'Ramily', 'Mangarivotra o', 331132047, 'chef comptable', '', '1743051558.jpg'),
(2, 'Zaho', 'zaho@gmail.com', NULL, '$2y$10$UTg.SPXalAocPK4lojlhxesDnpb03px1RfcyDuNvTDrh74QHLa.hW', NULL, '2025-02-22 06:03:08', '2025-02-22 06:03:08', 'user', 1, '', '', 0, '', '', ''),
(3, 'RABE', 'rabe@gmail.com', NULL, '$2y$10$jUy0hHcZJXH9E/3cPMp7gO23HluaPbAxuXb1ZSw9PPM2qfFd14eWC', NULL, '2025-02-22 06:03:33', '2025-02-22 06:03:33', 'user', 2, '', '', 0, '', '', ''),
(4, 'RABE', 'REGISTER@gmail.com', '2025-03-25 06:20:43', '$2y$10$Mdi4nk6c4wlpa1aZGOGofO7jmjybxVuUC0XqVwBpZOlF7n4MOL7xC', NULL, '2025-02-24 08:23:05', '2025-03-27 02:09:59', 'user', NULL, 'RADERABE', 'lot 13 iko', 326478945, 'militaire', 'DSIC', '1743052199.jpg'),
(5, 'TORORO', 'TORORO@gmail.com', NULL, '$2y$10$WzRh7z0hAOsAZCWrbTzs.uotgRWK/1ZqAscR5R/JGzH.2kbYEVlKe', NULL, '2025-02-24 09:00:48', '2025-02-24 09:00:48', 'user', NULL, 'TORORO', 'TORORO', 326478945, 'TORORO', 'TOROROTORORO', ''),
(6, 'DEL', 'del@gmail.com', NULL, '$2y$10$pgjSE13kvadLAmAkdrRQRu8TBHJXPGwzSb/m/JFcQ3cmPAWDBaoRW', NULL, '2025-02-25 01:53:42', '2025-02-25 01:53:42', 'user', NULL, 'RID', 'RID', 324566622, 'ETUDIANT', 'INSTAT', ''),
(19, 'DEL', 'magdella_emile@yahoo.com', '2025-03-12 07:16:32', '$2y$10$CLU6U5u1pMowOmoTdPFQIeM6HD77Fr1GWPAR/gkNgAYZ62h05p3TG', NULL, '2025-03-12 06:38:13', '2025-03-12 07:16:32', 'user', NULL, 'INSTAT', 'LOT', 321187872, 'ADT', 'INSTAT', ''),
(20, 'Rakoto', 'diary@gmail.com', '2025-03-27 05:58:05', '$2y$10$Ad0t0i6midXHwqLQfeDzpexSwGmHJcCdDb/ggrlIe.FC9uvoE4N/.', NULL, '2025-03-27 02:57:03', '2025-03-27 03:03:58', 'user', 1, 'Diary', 'anosy', 345684259, 'chef de division', 'Instat', '1743055438.jpg'),
(22, 'Randria', 'antonellanirina19@gmail.com', '2025-03-27 08:01:52', '$2y$10$clvMAm6vrfJKYG69R4GCNOZeU1METDGT8jtCJonfcEu8W90cAWPAy', NULL, '2025-03-27 08:01:26', '2025-03-28 08:27:41', 'user', 1, 'Antonella', '67 ha', 345684259, 'stagiaire', 'Instat', '1743073513.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
